package com.example.cleanbrowser.download

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

object Beep {
    /** One short beep (follows the phone's silent / vibrate mode). */
    fun play() {
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 400)
        }
    }
}
