package com.example.cleanbrowser.download

import android.content.Context
import android.net.Uri
import com.example.cleanbrowser.browser.VideoOption

object Downloader {

    /**
     * Starts the download at once. At most 3 run together; further ones wait in the queue and start
     * by themselves. A video that is already queued, paused or finished is reported as DUPLICATE.
     */
    fun enqueue(
        ctx: Context, option: VideoOption, pageUrl: String, userAgent: String, rawName: String,
        thumbUrl: String? = null,
    ): StartResult = DownloadEngine.enqueue(ctx, option, pageUrl, userAgent, rawName, thumbUrl)

    fun retry(id: String) = DownloadEngine.retry(id)

    /** Play button: resume a paused or failed download. */
    fun resume(id: String) = DownloadEngine.retry(id)

    /** Pause button. */
    fun pause(id: String) = DownloadEngine.pause(id)

    fun pauseAll() = DownloadEngine.pauseAll()

    fun resumeAll() = DownloadEngine.resumeAll()

    /** Removes the entry and deletes the file (partial or complete). */
    fun remove(ctx: Context, item: DownloadItem) = DownloadEngine.remove(ctx, item)

    /** Renames a finished file. The name always ends with .mp4. */
    fun rename(ctx: Context, item: DownloadItem, newName: String): Boolean {
        val uri = item.uri?.let { Uri.parse(it) } ?: return false
        val base = FileNames.base(newName)
        val moved = Storage.rename(ctx, uri, "$base.mp4") ?: return false
        DownloadStore.change(item.id) { it.copy(name = base, uri = moved.toString()) }
        return true
    }
}
