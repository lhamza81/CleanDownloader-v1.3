package com.example.cleanbrowser.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.download.AppSettings
import com.example.cleanbrowser.download.Storage

@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val s by AppSettings.state.collectAsState()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            AppSettings.update(ctx) { it.copy(folderUri = uri.toString()) }
        }
    }
    val folderName = remember(s.folderUri) { s.folderUri?.let { Storage.folderName(ctx, Uri.parse(it)) } ?: "Downloads" }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Download folder", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        folderName, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Choose folder") }
                        if (s.folderUri != null) {
                            TextButton(onClick = { AppSettings.update(ctx) { it.copy(folderUri = null) } }) { Text("Use Downloads") }
                        }
                    }
                }
                SwitchRow("Download with Wi-Fi only", "Waiting downloads start when you are on Wi-Fi", s.wifiOnly) { v ->
                    AppSettings.update(ctx) { it.copy(wifiOnly = v) }
                }
                SwitchRow("Block ads", "Drops known ad and tracker domains in the browser", s.blockAds) { v ->
                    AppSettings.update(ctx) { it.copy(blockAds = v) }
                }
                SwitchRow("Offer copied links", "Asks to open a link you just copied", s.clipboard) { v ->
                    AppSettings.update(ctx) { it.copy(clipboard = v) }
                }
                ChoiceRow("Simultaneous downloads", "Extra downloads wait in the queue", listOf(1, 2, 3), s.maxParallel) { v ->
                    AppSettings.update(ctx) { it.copy(maxParallel = v) }
                }
                ChoiceRow("Connections per file", "Big files are split over this many connections (up to 8)", listOf(1, 2, 4, 6, 8), s.connections) { v ->
                    AppSettings.update(ctx) { it.copy(connections = v) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SwitchRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceRow(title: String, hint: String, options: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
            options.forEach { n ->
                FilterChip(selected = selected == n, onClick = { onPick(n) }, label = { Text("$n") })
            }
        }
    }
}
