package com.example.cleanbrowser.download

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.webkit.CookieManager
import java.io.ByteArrayOutputStream
import java.io.File

/** Saves a small preview picture for a download: the page's poster image, else a frame of the video. */
object Thumbs {
    fun fetch(ctx: Context, id: String) {
        val item = DownloadStore.get(id) ?: return
        val dir = File(ctx.filesDir, "thumbs").also { it.mkdirs() }
        val out = File(dir, "$id.jpg")
        var ok = false
        val poster = item.thumbUrl
        if (poster != null && poster.startsWith("http")) {
            ok = runCatching { fromImage(poster, item, out) }.getOrDefault(false)
        }
        if (!ok && !item.isHls) ok = runCatching { fromVideo(item, out) }.getOrDefault(false)
        if (ok) DownloadStore.change(id) { it.copy(thumb = out.absolutePath) }
    }

    private fun fromImage(url: String, item: DownloadItem, out: File): Boolean {
        val c = Http.open(url, item.userAgent, item.pageUrl, timeout = 10_000)
        try {
            if (c.responseCode !in 200..299) return false
            val bytes = c.inputStream.use { s ->
                val buf = ByteArrayOutputStream()
                val tmp = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = s.read(tmp)
                    if (n < 0) break
                    total += n
                    if (total > 3_000_000) return false
                    buf.write(tmp, 0, n)
                }
                buf.toByteArray()
            }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return false
            save(bmp, out)
            return true
        } finally {
            c.disconnect()
        }
    }

    private fun fromVideo(item: DownloadItem, out: File): Boolean {
        val headers = mutableMapOf("User-Agent" to item.userAgent, "Referer" to item.pageUrl)
        runCatching { CookieManager.getInstance().getCookie(item.url) }.getOrNull()?.let { headers["Cookie"] = it }
        return MediaMetadataRetriever().use { r ->
            r.setDataSource(item.url, headers)
            val bmp = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime()
                ?: return@use false
            save(bmp, out)
            true
        }
    }

    private fun save(bmp: Bitmap, out: File) {
        val w = 480
        val scaled = if (bmp.width > w)
            Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt().coerceAtLeast(1), true)
        else bmp
        out.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }
    }
}
