package com.example.cleanbrowser.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** What the in-app player should open. */
data class PlayRequest(val uri: Uri, val title: String)

private fun clock(ms: Int): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, r) else String.format("%d:%02d", m, r)
}

private fun speedLabel(s: Float) = if (s % 1f == 0f) "${s.toInt()}x" else "${s}x"

/**
 * In-app player. Tap: show/hide controls. Double-tap left/right: back/forward 10 s.
 * Swipe sideways: seek. Swipe up/down on the left: brightness, on the right: volume.
 */
@Composable
fun PlayerScreen(uri: Uri, title: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as Activity
    val audio = remember { ctx.getSystemService(AudioManager::class.java) }
    val video = remember { arrayOfNulls<VideoView>(1) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }

    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableIntStateOf(0) }
    var scrubbing by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var speedMenu by remember { mutableStateOf(false) }
    var hud by remember { mutableStateOf<String?>(null) }
    var landscape by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(-1f) }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume)
    }

    BackHandler(onBack = onBack)

    DisposableEffect(Unit) {
        onDispose {
            video[0]?.stopPlayback()
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity.window.attributes = activity.window.attributes.also {
                it.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
        }
    }

    // Keeps the slider and the play/pause icon in step with the video.
    LaunchedEffect(Unit) {
        while (true) {
            video[0]?.let { v ->
                if (!scrubbing) position = v.currentPosition
                duration = v.duration.coerceAtLeast(0)
                playing = v.isPlaying
            }
            delay(250)
        }
    }
    LaunchedEffect(touch, controls, playing) {
        if (controls && playing) {
            delay(3500)
            controls = false
        }
    }
    LaunchedEffect(hud) {
        if (hud != null) {
            delay(900)
            hud = null
        }
    }

    fun seekTo(ms: Int) {
        video[0]?.seekTo(ms.coerceIn(0, duration.coerceAtLeast(0)))
    }

    fun setSpeed(s: Float) {
        speed = s
        val mp = player[0] ?: return
        runCatching {
            val wasPlaying = video[0]?.isPlaying == true
            mp.playbackParams = mp.playbackParams.setSpeed(s)
            if (!wasPlaying) video[0]?.pause()
        }
    }

    fun changeBrightness(delta: Float) {
        val current = if (brightness >= 0f) brightness
        else activity.window.attributes.screenBrightness.takeIf { it >= 0f } ?: 0.5f
        brightness = (current + delta).coerceIn(0.02f, 1f)
        activity.window.attributes = activity.window.attributes.also { it.screenBrightness = brightness }
        hud = "Brightness ${(brightness * 100).roundToInt()}%"
    }

    fun changeVolume(delta: Float) {
        volume = (volume + delta).coerceIn(0f, 1f)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volume * maxVolume).roundToInt(), 0)
        hud = "Volume ${(volume * 100).roundToInt()}%"
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                FrameLayout(c).also { frame ->
                    val vv = VideoView(c)
                    frame.addView(vv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.CENTER))
                    vv.setOnPreparedListener { mp ->
                        player[0] = mp
                        runCatching { if (speed != 1f) mp.playbackParams = mp.playbackParams.setSpeed(speed) }
                        vv.start()
                    }
                    vv.setOnErrorListener { _, _, _ ->
                        Toast.makeText(c, "This video can't be played", Toast.LENGTH_SHORT).show()
                        true
                    }
                    vv.setOnCompletionListener {
                        playing = false
                        controls = true
                    }
                    vv.setVideoURI(uri)
                    video[0] = vv
                }
            },
        )

        // Touch layer: taps and swipes.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { controls = !controls; touch++ },
                        onDoubleTap = { o ->
                            val back = o.x < size.width / 2f
                            seekTo((video[0]?.currentPosition ?: 0) + if (back) -10_000 else 10_000)
                            hud = if (back) "−10 s" else "+10 s"
                        },
                    )
                }
                .pointerInput(Unit) {
                    var horizontal: Boolean? = null
                    var startPos = 0
                    var startX = 0f
                    var travelled = 0f
                    detectDragGestures(
                        onDragStart = { o ->
                            horizontal = null
                            startX = o.x
                            travelled = 0f
                            startPos = video[0]?.currentPosition ?: 0
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            if (horizontal == null) horizontal = abs(drag.x) > abs(drag.y)
                            if (horizontal == true) {
                                travelled += drag.x
                                val deltaMs = (travelled / size.width * 90_000f).toInt()
                                val target = (startPos + deltaMs).coerceIn(0, duration.coerceAtLeast(0))
                                scrubbing = true
                                position = target
                                hud = "${clock(target)}  (${if (deltaMs >= 0) "+" else "−"}${abs(deltaMs) / 1000} s)"
                            } else if (startX < size.width / 2f) {
                                changeBrightness(-drag.y / size.height)
                            } else {
                                changeVolume(-drag.y / size.height)
                            }
                        },
                        onDragEnd = {
                            if (horizontal == true) seekTo(position)
                            scrubbing = false
                        },
                        onDragCancel = { scrubbing = false },
                    )
                },
        )

        hud?.let { text ->
            Text(
                text, color = Color.White, style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }

        AnimatedVisibility(visible = controls, modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f)).statusBarsPadding().padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                    Text(
                        title, color = Color.White, style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    Box {
                        TextButton(onClick = { speedMenu = true }) { Text(speedLabel(speed), color = Color.White) }
                        DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(speedLabel(s)) },
                                    onClick = { speedMenu = false; setSpeed(s); touch++ },
                                )
                            }
                        }
                    }
                    IconButton(onClick = {
                        landscape = !landscape
                        activity.requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                        touch++
                    }) { Icon(Icons.Filled.ScreenRotation, "Rotate", tint = Color.White) }
                }

                IconButton(
                    onClick = {
                        video[0]?.let { v -> if (v.isPlaying) v.pause() else v.start() }
                        touch++
                    },
                    modifier = Modifier.align(Alignment.Center).size(72.dp)
                        .background(Color.Black.copy(alpha = 0.45f), CircleShape),
                ) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if (playing) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(40.dp),
                    )
                }

                Row(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f)).navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(clock(position), color = Color.White, style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = position.toFloat(),
                        onValueChange = { scrubbing = true; position = it.toInt(); touch++ },
                        onValueChangeFinished = { seekTo(position); scrubbing = false },
                        valueRange = 0f..max(duration, 1).toFloat(),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    )
                    Text(clock(duration), color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
