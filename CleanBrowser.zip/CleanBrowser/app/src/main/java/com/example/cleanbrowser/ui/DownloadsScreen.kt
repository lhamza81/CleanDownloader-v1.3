package com.example.cleanbrowser.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.R
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.download.DlState
import com.example.cleanbrowser.download.DownloadItem
import com.example.cleanbrowser.download.DownloadStore
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.FileNames
import com.example.cleanbrowser.download.PrivateVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DownloadsMode { Active, Completed }

private val TrackGrey = Color(0xFFBDBDBD)
private val ProgressBlue = Color(0xFF1E88E5)

/**
 * Downloads: queued, downloading, paused, failed. Completed: finished files. One video per card.
 * Long-press a card to select several; then delete them (or lock finished ones in the private folder).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(mode: DownloadsMode, onPlay: (PlayRequest) -> Unit, onOpenPage: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val all by DownloadStore.items.collectAsState()
    val list = all.filter { (it.state == DlState.COMPLETED) == (mode == DownloadsMode.Completed) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val selecting = selected.isNotEmpty()

    LaunchedEffect(list) { selected = selected.filter { id -> list.any { it.id == id } }.toSet() }
    BackHandler(enabled = selecting) { selected = emptySet() }

    Scaffold(
        topBar = {
            if (selecting) {
                TopAppBar(
                    title = { Text("${selected.size} selected") },
                    navigationIcon = {
                        IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Filled.Close, "Cancel selection") }
                    },
                    actions = {
                        IconButton(onClick = { selected = list.map { it.id }.toSet() }) {
                            Icon(Icons.Filled.SelectAll, "Select all")
                        }
                        if (mode == DownloadsMode.Completed) {
                            IconButton(onClick = {
                                val chosen = list.filter { it.id in selected }
                                selected = emptySet()
                                scope.launch {
                                    var moved = 0
                                    chosen.forEach { if (PrivateVault.moveIn(ctx, it)) moved++ }
                                    Toast.makeText(ctx, "$moved moved to the private folder", Toast.LENGTH_SHORT).show()
                                }
                            }) { Icon(Icons.Filled.Lock, "Move to the private folder") }
                        }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
                    },
                )
            } else {
                TopAppBar(
                    title = { Text(if (mode == DownloadsMode.Active) "Downloads" else "Completed") },
                    actions = {
                        var menu by remember { mutableStateOf(false) }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Pause all") }, onClick = { menu = false; Downloader.pauseAll() })
                            DropdownMenuItem(text = { Text("Resume all") }, onClick = { menu = false; Downloader.resumeAll() })
                            DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; showSettings = true })
                        }
                    },
                )
            }
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        if (list.isEmpty()) {
            Text(
                if (mode == DownloadsMode.Active) "No active downloads" else "No completed downloads yet",
                modifier = Modifier.padding(padding).padding(24.dp),
            )
        }
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { item ->
                val isSelected = item.id in selected
                val toggle = { selected = if (isSelected) selected - item.id else selected + item.id }
                val longPress = { if (!isSelected) selected = selected + item.id }
                if (item.state == DlState.COMPLETED) {
                    CompletedCard(item, selecting, isSelected, toggle, longPress, onPlay, onOpenPage)
                } else {
                    ActiveCard(item, selecting, isSelected, toggle, longPress, onOpenPage)
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${selected.size} file${if (selected.size > 1) "s" else ""}?") },
            text = { Text("They will be removed from your phone.") },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
            confirmButton = {
                TextButton(onClick = {
                    list.filter { it.id in selected }.forEach { Downloader.remove(ctx, it) }
                    selected = emptySet()
                    confirmDelete = false
                }) { Text("Delete") }
            },
        )
    }
    if (showSettings) SettingsDialog { showSettings = false }
}

// ---------------------------------------------------------------------------------------------
// pieces
// ---------------------------------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun cardModifier(selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit): Modifier =
    Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow)
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .padding(12.dp)

/** Grey line that fills with blue as the download progresses. */
@Composable
private fun ProgressLine(fraction: Float) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), label = "progress")
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(TrackGrey)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(animated).background(ProgressBlue))
    }
}

/** Full name, always ending in .mp4, with a check mark while selected. */
@Composable
private fun NameLine(item: DownloadItem, selected: Boolean) {
    Row(verticalAlignment = Alignment.Top) {
        if (selected) {
            Icon(
                Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 6.dp, top = 2.dp).size(18.dp),
            )
        }
        Text(FileNames.full(item.name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

/** Preview picture: a frame of the finished file, else the picture saved when the download started. */
@Composable
private fun ThumbBox(savedPath: String?, frame: Bitmap?) {
    val saved by produceState<Bitmap?>(null, savedPath) {
        value = savedPath?.let { p ->
            withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(p) }.getOrNull() }
        }
    }
    val bmp = frame ?: saved
    Box(
        Modifier.width(112.dp).height(72.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Filled.Movie, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** The web-link icon: tap it to open the page the video came from, in the browser. */
@Composable
private fun PageLinkButton(pageUrl: String, onOpenPage: (String) -> Unit) {
    if (pageUrl.isBlank()) return
    IconButton(onClick = { onOpenPage(pageUrl) }) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
            Image(
                painterResource(R.drawable.ic_web_link), "Open the video page",
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/** Queued / downloading / paused / failed: preview, name, rate, grey-to-blue line, percentage below it. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ActiveCard(
    item: DownloadItem,
    selecting: Boolean,
    selected: Boolean,
    onToggle: () -> Unit,
    onLongPress: () -> Unit,
    onOpenPage: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val fraction = if (item.total > 0) (item.downloaded.toFloat() / item.total).coerceIn(0f, 1f) else 0f
    val pct = (fraction * 100).toInt()
    val approx = if (item.isHls) "≈ " else ""

    // Counts down to the automatic retry of a failed download.
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(item.state) {
        while (item.state == DlState.FAILED) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val retryIn = if (item.state == DlState.FAILED && item.retryAt > 0) ((item.retryAt - now) / 1000).coerceAtLeast(0) else -1L

    val left = when (item.state) {
        DlState.QUEUED -> "Waiting in queue"
        DlState.PAUSED -> "Paused"
        DlState.FAILED -> (item.error ?: "Download failed") + if (retryIn >= 0) " · retrying in ${retryIn}s" else ""
        else -> when {
            item.total > 0 -> "${Fmt.size(item.downloaded)} / $approx${Fmt.size(item.total)}"
            item.downloaded > 0 -> Fmt.size(item.downloaded)
            else -> "Starting…"
        }
    }
    val rate = if (item.state == DlState.DOWNLOADING && item.speedBps > 0) Fmt.rate(item.speedBps) else ""
    val percentText = "$pct%" + (item.note?.let { " · $it" } ?: "") + when (item.state) {
        DlState.QUEUED -> if (item.note == null) " · waiting" else ""
        DlState.PAUSED -> " · paused"
        DlState.FAILED -> " · failed"
        else -> ""
    }

    Column(
        cardModifier(selected, onClick = { if (selecting) onToggle() }, onLongClick = onLongPress),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            ThumbBox(item.thumb, null)
            Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                NameLine(item, selected)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        left, style = MaterialTheme.typography.bodySmall,
                        color = if (item.state == DlState.FAILED) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    if (rate.isNotEmpty()) Text(rate, style = MaterialTheme.typography.labelLarge, color = ProgressBlue)
                }
                ProgressLine(fraction)
                Text(percentText, style = MaterialTheme.typography.bodySmall)        // below the line
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            PageLinkButton(item.pageUrl, onOpenPage)
            when (item.state) {
                DlState.DOWNLOADING, DlState.QUEUED ->
                    IconButton(onClick = { Downloader.pause(item.id) }) { Icon(Icons.Filled.Pause, "Pause") }
                else ->
                    IconButton(onClick = { Downloader.resume(item.id) }) { Icon(Icons.Filled.PlayArrow, "Resume") }
            }
            IconButton(onClick = { Downloader.remove(ctx, item) }) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}

/** Finished file: preview, full name, size, length, and whether the audio came along. Tap to play. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CompletedCard(
    item: DownloadItem,
    selecting: Boolean,
    selected: Boolean,
    onToggle: () -> Unit,
    onLongPress: () -> Unit,
    onPlay: (PlayRequest) -> Unit,
    onOpenPage: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val uri = remember(item.uri) { item.uri?.let { Uri.parse(it) } }
    val info by rememberMediaInfo(uri)
    var renaming by remember { mutableStateOf(false) }
    val meta = listOfNotNull(
        (info?.sizeBytes ?: item.total.takeIf { it > 0 })?.let { Fmt.size(it) },
        info?.durationSec?.let { Fmt.duration(it) },
        when (info?.hasAudio) { true -> "With audio"; false -> "No audio"; null -> null },
    ).joinToString(" · ")

    Column(
        cardModifier(
            selected,
            onClick = {
                if (selecting) onToggle() else uri?.let { onPlay(PlayRequest(it, FileNames.full(item.name))) }
            },
            onLongClick = onLongPress,
        ),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            ThumbBox(item.thumb, info?.frame)
            Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                NameLine(item, selected)
                if (meta.isNotEmpty()) {
                    Text(
                        meta, style = MaterialTheme.typography.bodySmall,
                        color = if (info?.hasAudio == false) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            PageLinkButton(item.pageUrl, onOpenPage)
            IconButton(onClick = { renaming = true }) { Icon(Icons.Filled.Edit, "Rename") }
            IconButton(onClick = { Downloader.remove(ctx, item) }) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }

    if (renaming) {
        RenameDialog(item.name, onDismiss = { renaming = false }) { newName ->
            val ok = Downloader.rename(ctx, item, newName)
            Toast.makeText(ctx, if (ok) "Renamed" else "Couldn't rename", Toast.LENGTH_SHORT).show()
            renaming = false
        }
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                suffix = { Text(".mp4") },
                minLines = 1,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text("Rename") } },
    )
}
