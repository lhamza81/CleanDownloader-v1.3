package com.example.cleanbrowser.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.download.StatusFile
import com.example.cleanbrowser.download.StatusSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun rememberImageThumb(uri: Uri, sample: Int): State<Bitmap?> {
    val ctx = LocalContext.current
    return produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            }.getOrNull()
        }
    }
}

/** WhatsApp statuses kept on the phone: look at them and save the ones you want. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusScreen(onBack: () -> Unit, onPlay: (PlayRequest) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tree by remember { mutableStateOf(StatusSaver.treeUri(ctx)) }
    var files by remember { mutableStateOf<List<StatusFile>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }          // 0 all, 1 videos, 2 pictures
    var viewing by remember { mutableStateOf<StatusFile?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            StatusSaver.saveTree(ctx, uri)
            tree = uri
            refresh++
        }
    }

    LaunchedEffect(tree, refresh) {
        val t = tree ?: return@LaunchedEffect
        files = null
        failed = false
        runCatching { StatusSaver.list(ctx, t) }
            .onSuccess { files = it }
            .onFailure { failed = true; files = emptyList() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WhatsApp status") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (tree != null) {
                        IconButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, "Refresh") }
                        IconButton(onClick = { picker.launch(StatusSaver.pickerHint()) }) {
                            Icon(Icons.Filled.FolderOpen, "Change folder")
                        }
                    }
                },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            val list = files
            when {
                tree == null || failed -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        if (failed) "The folder can't be read any more. Allow access again."
                        else "To save statuses, give CleanDownloader access to the WhatsApp Status folder.",
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Open WhatsApp and view the status first. Then tap Allow access and press \"Use this folder\".",
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = { picker.launch(StatusSaver.pickerHint()) }) { Text("Allow access") }
                }
                list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> Column(Modifier.fillMaxSize()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All", "Videos", "Pictures").forEachIndexed { i, label ->
                            FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
                        }
                    }
                    val shown = list.filter { filter == 0 || (filter == 1 && it.isVideo) || (filter == 2 && !it.isVideo) }
                    if (shown.isEmpty()) {
                        Text("No statuses found. View a status in WhatsApp, then tap Refresh.", modifier = Modifier.padding(24.dp))
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(shown, key = { it.uri.toString() }) { f ->
                            StatusTile(
                                f,
                                onOpen = { if (f.isVideo) onPlay(PlayRequest(f.uri, f.name)) else viewing = f },
                                onSave = {
                                    scope.launch {
                                        val ok = StatusSaver.save(ctx, f)
                                        Toast.makeText(ctx, if (ok) "Saved" else "Couldn't save it", Toast.LENGTH_SHORT).show()
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }

    viewing?.let { f ->
        val bmp by rememberImageThumb(f.uri, 2)
        AlertDialog(
            onDismissRequest = { viewing = null },
            text = {
                bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit) }
            },
            dismissButton = { TextButton(onClick = { viewing = null }) { Text("Close") } },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val ok = StatusSaver.save(ctx, f)
                        Toast.makeText(ctx, if (ok) "Saved" else "Couldn't save it", Toast.LENGTH_SHORT).show()
                    }
                    viewing = null
                }) { Text("Save") }
            },
        )
    }
}

@Composable
private fun StatusTile(f: StatusFile, onOpen: () -> Unit, onSave: () -> Unit) {
    val info by rememberMediaInfo(if (f.isVideo) f.uri else null)
    val picture by rememberImageThumb(f.uri, 4)
    val bmp = if (f.isVideo) info?.frame else picture

    Box(
        Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onOpen),
    ) {
        if (bmp != null) {
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        if (f.isVideo) {
            Icon(
                Icons.Filled.PlayArrow, null, tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(30.dp)
                    .background(Color.Black.copy(alpha = 0.45f), CircleShape),
            )
        }
        IconButton(
            onClick = onSave,
            modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).size(34.dp)
                .background(Color.Black.copy(alpha = 0.55f), CircleShape),
        ) { Icon(Icons.Filled.Download, "Save", tint = Color.White, modifier = Modifier.size(20.dp)) }
    }
}
