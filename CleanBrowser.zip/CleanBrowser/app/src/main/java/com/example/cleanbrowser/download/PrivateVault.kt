package com.example.cleanbrowser.download

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

data class PrivateItem(
    val id: String,
    val name: String,       // base name, no extension
    val file: String,       // path inside the app's private storage
    val url: String,        // where it came from
    val size: Long,
    val addedAt: Long,
    val page: String = "",  // the page the video came from
)

/**
 * Videos moved here live in the app's own storage: the gallery and other apps can't see them, and
 * this screen is opened with a PIN. The files themselves are not encrypted.
 */
object PrivateVault {
    private var prefs: SharedPreferences? = null
    private val _items = MutableStateFlow<List<PrivateItem>>(emptyList())
    val items: StateFlow<List<PrivateItem>> = _items.asStateFlow()

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("vault", Context.MODE_PRIVATE)
        prefs = p
        _items.value = runCatching {
            val arr = JSONArray(p.getString("items", "[]"))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                PrivateItem(o.getString("id"), o.getString("name"), o.getString("file"), o.optString("url"), o.optLong("size"), o.optLong("at"), o.optString("page"))
            }.filter { File(it.file).exists() }
        }.getOrDefault(emptyList())
    }

    private fun save() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("file", it.file)
                .put("url", it.url).put("size", it.size).put("at", it.addedAt).put("page", it.page))
        }
        prefs?.edit()?.putString("items", arr.toString())?.apply()
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "private").also { it.mkdirs() }

    // ---------- PIN ----------

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(ctx: Context): Boolean {
        init(ctx)
        return prefs?.getString("pin_hash", null) != null
    }

    fun setPin(ctx: Context, pin: String) {
        init(ctx)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        prefs?.edit()?.putString("pin_salt", salt)?.putString("pin_hash", hash(salt, pin))?.apply()
    }

    fun checkPin(ctx: Context, pin: String): Boolean {
        init(ctx)
        val salt = prefs?.getString("pin_salt", null) ?: return false
        return prefs?.getString("pin_hash", null) == hash(salt, pin)
    }

    // ---------- files ----------

    /** Moves a finished download into the private folder (it leaves Downloads and the Completed list). */
    suspend fun moveIn(ctx: Context, item: DownloadItem): Boolean = withContext(Dispatchers.IO) {
        init(ctx)
        val src = item.uri?.let { Uri.parse(it) } ?: return@withContext false
        val out = File(dir(ctx), UUID.randomUUID().toString() + ".mp4")
        try {
            ctx.contentResolver.openInputStream(src)!!.use { input ->
                out.outputStream().use { input.copyTo(it) }
            }
        } catch (e: Exception) {
            out.delete()
            return@withContext false
        }
        Storage.delete(ctx, src)
        DownloadStore.remove(item.id)
        _items.update { listOf(PrivateItem(item.id, item.name, out.absolutePath, item.url, out.length(), System.currentTimeMillis(), item.pageUrl)) + it }
        save()
        true
    }

    /** Moves a video back to the download folder; it shows up in Completed again. */
    suspend fun moveOut(ctx: Context, p: PrivateItem): Boolean = withContext(Dispatchers.IO) {
        val src = File(p.file)
        if (!src.exists()) return@withContext false
        val dest = try { Storage.create(ctx, FileNames.full(p.name)) } catch (e: Exception) { return@withContext false }
        try {
            ctx.contentResolver.openOutputStream(dest, "wt")!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            Storage.finish(ctx, dest)
        } catch (e: Exception) {
            Storage.delete(ctx, dest)
            return@withContext false
        }
        src.delete()
        DownloadStore.add(
            DownloadItem(
                id = p.id, url = p.url, pageUrl = p.page, userAgent = "", name = p.name,
                state = DlState.COMPLETED, uri = dest.toString(), downloaded = p.size, total = p.size,
                error = null, createdAt = System.currentTimeMillis(),
            )
        )
        _items.update { list -> list.filterNot { it.id == p.id } }
        save()
        true
    }

    fun delete(p: PrivateItem) {
        File(p.file).delete()
        _items.update { list -> list.filterNot { it.id == p.id } }
        save()
    }
}
