package com.example.cleanbrowser.browser

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

data class LibraryEntry(val title: String, val url: String, val time: Long)

/** A saved list of pages, newest first, one entry per address. */
class EntryList(private val key: String, private val cap: Int) {
    private val _items = MutableStateFlow<List<LibraryEntry>>(emptyList())
    val items: StateFlow<List<LibraryEntry>> = _items.asStateFlow()
    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("library", Context.MODE_PRIVATE)
        prefs = p
        _items.value = runCatching {
            val arr = JSONArray(p.getString(key, "[]"))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                LibraryEntry(o.optString("t"), o.getString("u"), o.optLong("at"))
            }
        }.getOrDefault(emptyList())
    }

    fun put(e: LibraryEntry) {
        _items.update { list -> (listOf(e) + list.filterNot { it.url == e.url }).take(cap) }
        save()
    }

    fun remove(url: String) {
        _items.update { list -> list.filterNot { it.url == url } }
        save()
    }

    fun clear() {
        _items.value = emptyList()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        _items.value.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url).put("at", it.time)) }
        prefs?.edit()?.putString(key, arr.toString())?.apply()
    }
}

object Library {
    val bookmarks = EntryList("bookmarks", 1000)
    val history = EntryList("history", 500)

    fun init(ctx: Context) {
        bookmarks.init(ctx)
        history.init(ctx)
    }
}
