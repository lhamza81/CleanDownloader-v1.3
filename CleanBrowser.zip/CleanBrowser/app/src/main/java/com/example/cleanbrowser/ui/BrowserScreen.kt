package com.example.cleanbrowser.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.cleanbrowser.BrowserViewModel
import com.example.cleanbrowser.browser.BrowserTab
import com.example.cleanbrowser.browser.ClipboardLinks
import com.example.cleanbrowser.browser.Library
import com.example.cleanbrowser.browser.LibraryEntry
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.VideoDetector
import com.example.cleanbrowser.browser.TabManager
import com.example.cleanbrowser.download.DlState
import com.example.cleanbrowser.download.DownloadItem
import com.example.cleanbrowser.download.DownloadStore
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.StartResult
import com.example.cleanbrowser.download.FileNames
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private enum class Screen { Browser, Downloads, Completed, Tabs, Library, Private, Status }

@Composable
fun BrowserScreen(vm: BrowserViewModel = viewModel()) {
    val mgr = vm.tabManager
    val ctx = LocalContext.current
    val fullscreenView = mgr.customView
    var screen by remember { mutableStateOf(Screen.Browser) }
    var playing by remember { mutableStateOf<PlayRequest?>(null) }
    var libraryTab by remember { mutableIntStateOf(0) }
    val items by DownloadStore.items.collectAsState()
    val activeCount = items.count { it.state != DlState.COMPLETED && it.state != DlState.FAILED }
    val showBar = playing == null &&
        (screen == Screen.Browser || screen == Screen.Downloads || screen == Screen.Completed)
    // The web-link icon in the download lists: open the video's page in a new tab.
    val openPage: (String) -> Unit = { url ->
        screen = Screen.Browser
        if (!mgr.newTab(url)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
    }

    BackHandler(enabled = fullscreenView == null && playing == null && screen != Screen.Browser) { screen = Screen.Browser }
    BackHandler(enabled = fullscreenView == null && playing == null && screen == Screen.Browser && mgr.activeTab?.canGoBack == true) { mgr.goBack() }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = { if (showBar) SectionBar(screen, activeCount) { screen = it } },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.Browser -> BrowserContent(
                        mgr,
                        onTabs = { screen = Screen.Tabs },
                        onLibrary = { t -> libraryTab = t; screen = Screen.Library },
                        onPrivate = { screen = Screen.Private },
                        onStatus = { screen = Screen.Status },
                    )
                    Screen.Downloads -> DownloadsScreen(DownloadsMode.Active, onPlay = { playing = it }, onOpenPage = openPage)
                    Screen.Completed -> DownloadsScreen(DownloadsMode.Completed, onPlay = { playing = it }, onOpenPage = openPage)
                    Screen.Library -> LibraryScreen(
                        libraryTab,
                        onOpen = { url -> mgr.load(url); screen = Screen.Browser },
                        onBack = { screen = Screen.Browser },
                    )
                    Screen.Private -> PrivateScreen(onBack = { screen = Screen.Browser }, onPlay = { playing = it })
                    Screen.Status -> StatusScreen(onBack = { screen = Screen.Browser }, onPlay = { playing = it })
                    Screen.Tabs -> TabSwitcher(
                        tabs = mgr.tabs,
                        activeId = mgr.activeId,
                        onSelect = { mgr.select(it); screen = Screen.Browser },
                        onClose = { mgr.closeTab(it) },
                        onNew = {
                            if (mgr.newTab()) screen = Screen.Browser
                            else Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { screen = Screen.Browser },
                    )
                }
            }
        }

        // In-app player (overlay)
        playing?.let { req -> PlayerScreen(req.uri, req.title) { playing = null } }
        // Overlay (not a replacement) so the WebView stays attached and playback continues.
        if (fullscreenView != null) FullscreenVideo(fullscreenView, onExit = mgr::exitFullscreen)

        CompletedBubble(
            Modifier.align(Alignment.BottomCenter).padding(bottom = if (showBar) 112.dp else 28.dp),
            onClick = { screen = Screen.Completed },
        )
    }

    // "Link you copied": a direct video link goes straight to the download window, a page opens in a new tab.
    vm.clipboardLink?.let { link ->
        AlertDialog(
            onDismissRequest = vm::dismissClipboard,
            title = { Text("Link you copied") },
            text = { Text(link, maxLines = 4, overflow = TextOverflow.Ellipsis) },
            dismissButton = { TextButton(onClick = vm::dismissClipboard) { Text("Dismiss") } },
            confirmButton = {
                TextButton(onClick = {
                    vm.dismissClipboard()
                    screen = Screen.Browser
                    val direct = VideoDetector.classify(link)
                    if (direct != null) mgr.openDirectVideo(direct)
                    else if (!mgr.newTab(link)) {
                        Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Open") }
            },
        )
    }
}

/** Bottom tabs: Browser, Downloads (in progress), Completed (finished files). */
@Composable
private fun SectionBar(selected: Screen, activeCount: Int, onSelect: (Screen) -> Unit) {
    NavigationBar {
        NavigationBarItem(
            selected = selected == Screen.Browser, onClick = { onSelect(Screen.Browser) },
            icon = { Icon(Icons.Filled.Public, null) }, label = { Text("Browser") },
        )
        NavigationBarItem(
            selected = selected == Screen.Downloads, onClick = { onSelect(Screen.Downloads) },
            icon = {
                BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                    Icon(Icons.Filled.Download, null)
                }
            },
            label = { Text("Downloads") },
        )
        NavigationBarItem(
            selected = selected == Screen.Completed, onClick = { onSelect(Screen.Completed) },
            icon = { Icon(Icons.Filled.DownloadDone, null) }, label = { Text("Completed") },
        )
    }
}

/** Small sky-blue balloon at the bottom with the name of the video that just finished. */
@Composable
private fun CompletedBubble(modifier: Modifier, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        DownloadStore.completed.collect { name ->
            shown = name
            visible = true
            delay(3500)
            visible = false
            delay(300)
        }
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut(),
        modifier = modifier,
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF87CEEB))   // sky blue
                .clickable { visible = false; onClick() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF0B3954), modifier = Modifier.size(16.dp))
            Text(
                shown,
                color = Color(0xFF0B3954),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 260.dp).padding(start = 6.dp),
            )
        }
    }
}

@Composable
private fun BrowserContent(
    mgr: TabManager,
    onTabs: () -> Unit,
    onLibrary: (Int) -> Unit,
    onPrivate: () -> Unit,
    onStatus: () -> Unit,
) {
    val ctx = LocalContext.current
    val tab = mgr.activeTab
    var showSettings by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.statusBarsPadding()) {
            TabStrip(
                tabs = mgr.tabs,
                activeId = mgr.activeId,
                onSelect = { mgr.select(it) },
                onClose = { mgr.closeTab(it) },
                onNew = {
                    if (!mgr.newTab()) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                },
                trailing = { BrowserMenu(tab, onLibrary, onPrivate, onStatus) { showSettings = true } },
            )
            if (tab != null) AddressRow(tab, mgr, onTabs)
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val density = LocalDensity.current
            val fabPx = with(density) { 60.dp.toPx() }
            val margin = with(density) { 16.dp.toPx() }
            val maxX = (constraints.maxWidth - fabPx).coerceAtLeast(0f)
            val maxY = (constraints.maxHeight - fabPx).coerceAtLeast(0f)
            // Button position: starts bottom-right, then wherever the user drags it.
            var fabX by remember { mutableFloatStateOf(-1f) }
            var fabY by remember { mutableFloatStateOf(-1f) }
            if (fabX < 0f) { fabX = maxX - margin; fabY = maxY - margin }

            if (tab != null) {
                key(tab.id) {
                    AndroidView(factory = { mgr.webViewFor(tab) }, modifier = Modifier.fillMaxSize())
                }
                if (tab.progress in 1..99) {
                    LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
                }
                if (tab.videos.isNotEmpty()) {
                    DownloadFab(
                        modifier = Modifier
                            .offset { IntOffset(fabX.coerceIn(0f, maxX).roundToInt(), fabY.coerceIn(0f, maxY).roundToInt()) }
                            .pointerInput(maxX, maxY) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    fabX = (fabX + drag.x).coerceIn(0f, maxX)
                                    fabY = (fabY + drag.y).coerceIn(0f, maxY)
                                }
                            },
                        onClick = {
                            mgr.scanActive()          // pick up videos that only exist in the page itself
                            mgr.showDownloadDialog = true
                        },
                    )
                }
            }
        }
    }

    if (showSettings) SettingsDialog { showSettings = false }

    mgr.linkMenu?.let { link ->
        AlertDialog(
            onDismissRequest = mgr::dismissLinkMenu,
            title = { Text(link, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text("Open in new tab") },
                        leadingContent = { Icon(Icons.Filled.Add, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            if (!mgr.newTab(link)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                            mgr.dismissLinkMenu()
                        },
                    )
                    ListItem(
                        headlineContent = { Text("Copy link") },
                        leadingContent = { Icon(Icons.Filled.ContentCopy, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            ctx.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("link", link))
                            ClipboardLinks.markHandled(ctx, link)
                            mgr.dismissLinkMenu()
                        },
                    )
                }
            },
            confirmButton = { TextButton(onClick = mgr::dismissLinkMenu) { Text("Cancel") } },
        )
    }

    if (mgr.showDownloadDialog && tab != null) {
        DownloadOptionsDialog(
            videos = tab.videos,
            pageUrl = tab.url,
            pageTitle = tab.title,
            userAgent = mgr.userAgent,
            webView = mgr.activeWebView(),
            onDismiss = { mgr.showDownloadDialog = false },
        ) { option, name, thumbUrl ->
            val result = Downloader.enqueue(ctx, option, tab.url, mgr.userAgent, name, thumbUrl)
            Toast.makeText(
                ctx,
                when (result) {
                    StartResult.STARTED -> "Download started"
                    StartResult.QUEUED -> "Added to the queue"
                    StartResult.DUPLICATE -> "Already downloaded"
                },
                Toast.LENGTH_SHORT,
            ).show()
            mgr.showDownloadDialog = false
        }
    }
}

/** Round download button: drag it anywhere on the page, tap it to open the video list. */
@Composable
private fun DownloadFab(modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.size(60.dp).clickable(onClick = onClick),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        shadowElevation = 6.dp,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                Icons.Filled.Download, "Download video",
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(28.dp),
            )
        }
    }
}

/** Back, Forward, Home, address field and the tab counter in one row. */
@Composable
private fun AddressRow(tab: BrowserTab, mgr: TabManager, onTabs: () -> Unit) {
    val focus = LocalFocusManager.current
    var text by remember(tab.id, tab.url) { mutableStateOf(tab.url) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { mgr.goBack() }, enabled = tab.canGoBack, modifier = Modifier.size(38.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
        }
        IconButton(onClick = { mgr.goForward() }, enabled = tab.canGoForward, modifier = Modifier.size(38.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward")
        }
        IconButton(onClick = { mgr.load(TabManager.HOME) }, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.Home, "Home")
        }
        TextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { mgr.go(text); focus.clearFocus() }),
            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
        )
        Box(Modifier.size(38.dp).clickable(onClick = onTabs), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(24.dp).border(2.dp, MaterialTheme.colorScheme.onSurfaceVariant, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center,
            ) { Text("${mgr.tabs.size}", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun FullscreenVideo(view: View, onExit: () -> Unit) {
    val activity = LocalContext.current as Activity
    BackHandler(onBack = onExit)
    DisposableEffect(Unit) {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        factory = { (view.parent as? ViewGroup)?.removeView(view); view },
        modifier = Modifier.fillMaxSize().background(Color.Black),
    )
}

/** The three-dot menu next to "+": bookmarks, history, private folder, WhatsApp status, settings. */
@Composable
private fun BrowserMenu(
    tab: BrowserTab?,
    onLibrary: (Int) -> Unit,
    onPrivate: () -> Unit,
    onStatus: () -> Unit,
    onSettings: () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val marks by Library.bookmarks.items.collectAsState()
    val marked = tab != null && marks.any { it.url == tab.url }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(if (marked) "Remove bookmark" else "Add bookmark") },
                enabled = tab != null,
                onClick = {
                    open = false
                    if (tab != null) {
                        if (marked) Library.bookmarks.remove(tab.url)
                        else Library.bookmarks.put(LibraryEntry(tab.title.ifBlank { tab.url }, tab.url, System.currentTimeMillis()))
                    }
                },
            )
            DropdownMenuItem(text = { Text("Bookmarks") }, onClick = { open = false; onLibrary(0) })
            DropdownMenuItem(text = { Text("History") }, onClick = { open = false; onLibrary(1) })
            DropdownMenuItem(text = { Text("Private folder") }, onClick = { open = false; onPrivate() })
            DropdownMenuItem(text = { Text("WhatsApp status") }, onClick = { open = false; onStatus() })
            DropdownMenuItem(text = { Text("Settings") }, onClick = { open = false; onSettings() })
        }
    }
}
