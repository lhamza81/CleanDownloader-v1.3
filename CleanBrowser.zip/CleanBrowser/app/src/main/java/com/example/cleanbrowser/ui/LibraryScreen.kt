package com.example.cleanbrowser.ui

import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.Library

/** Bookmarks (tab 0) and history (tab 1). Tap a page to open it. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(initialTab: Int, onOpen: (String) -> Unit, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(initialTab) }
    val marks by Library.bookmarks.items.collectAsState()
    val history by Library.history.items.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    val list = if (tab == 0) marks else history

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bookmarks and history") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (tab == 1 && history.isNotEmpty()) {
                        IconButton(onClick = { confirmClear = true }) { Icon(Icons.Filled.DeleteSweep, "Clear history") }
                    }
                },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Bookmarks") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("History") })
            }
            if (list.isEmpty()) {
                Text(if (tab == 0) "No bookmarks yet" else "No history yet", modifier = Modifier.padding(24.dp))
            }
            LazyColumn {
                items(list, key = { it.url }) { e ->
                    ListItem(
                        headlineContent = { Text(e.title.ifBlank { e.url }, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        supportingContent = {
                            val whenText = if (tab == 1 && e.time > 0)
                                "\n" + DateUtils.getRelativeTimeSpanString(e.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
                            else ""
                            Text(e.url + whenText, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        },
                        trailingContent = {
                            IconButton(onClick = { (if (tab == 0) Library.bookmarks else Library.history).remove(e.url) }) {
                                Icon(Icons.Filled.Close, "Remove")
                            }
                        },
                        modifier = Modifier.clickable { onOpen(e.url) },
                    )
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all history?") },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
            confirmButton = { TextButton(onClick = { Library.history.clear(); confirmClear = false }) { Text("Clear") } },
        )
    }
}
