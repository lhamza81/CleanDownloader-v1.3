package com.example.cleanbrowser.browser

import android.webkit.WebView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

data class PageInfo(
    val title: String,
    val author: String,
    val site: String,
    val host: String,
    val thumb: String = "",      // poster / og:image of the page
)

/** Reads the video's full title, channel/creator, site name and poster from the loaded page. */
object PageMetadata {

    private const val MAX_NAME = 120

    // Runs inside the page. Tries Open Graph, JSON-LD (VideoObject), YouTube player data and common meta tags.
    private const val JS = """
    (function(){
      function m(sel){var e=document.querySelector(sel);
        return e?((e.content||e.getAttribute('content')||e.textContent||'')+'').trim():'';}
      var host=location.hostname.replace(/^www\./,'');
      var title=m('meta[property="og:title"]')||m('meta[name="twitter:title"]')||document.title||'';
      var author='';
      try{
        var ls=document.querySelectorAll('script[type="application/ld+json"]');
        for(var i=0;i<ls.length&&!author;i++){
          var d=JSON.parse(ls[i].textContent);
          var arr=Array.isArray(d)?d:(d['@graph']||[d]);
          for(var j=0;j<arr.length&&!author;j++){
            var a=arr[j]&&(arr[j].author||arr[j].creator||arr[j].uploader);
            if(Array.isArray(a))a=a[0];
            if(a)author=(typeof a==='string'?a:a.name)||'';
          }
        }
      }catch(e){}
      if(!author){try{author=ytInitialPlayerResponse.videoDetails.author||'';}catch(e){}}
      if(!author)author=m('[itemprop="author"] [itemprop="name"]')||m('meta[name="author"]')
        ||m('meta[property="article:author"]')||m('meta[name="twitter:creator"]');
      author=author.replace(/^@/,'');
      var site=m('meta[property="og:site_name"]')||host;
      var thumb=m('meta[property="og:image"]')||m('meta[name="twitter:image"]')||'';
      if(!thumb){var pv=document.querySelector('video[poster]'); if(pv) thumb=pv.getAttribute('poster')||'';}
      try{ if(thumb) thumb=new URL(thumb, location.href).href; }catch(e){}
      return JSON.stringify({title:title,author:author,site:site,host:host,thumb:thumb});
    })()
    """

    /** Must be called on the main thread. Returns null if the page can't be read in time. */
    suspend fun read(wv: WebView?): PageInfo? = withTimeoutOrNull(3000) {
        if (wv == null) return@withTimeoutOrNull null
        suspendCancellableCoroutine<PageInfo?> { cont ->
            wv.evaluateJavascript(JS) { raw ->
                val info = runCatching {
                    val str = JSONTokener(raw).nextValue() as? String ?: return@runCatching null
                    val o = JSONObject(str)
                    PageInfo(
                        o.optString("title"), o.optString("author"), o.optString("site"),
                        o.optString("host"), o.optString("thumb"),
                    )
                }.getOrNull()
                if (cont.isActive) cont.resume(info)
            }
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** True if [name] already appears in [text] (ignoring case, spaces and punctuation). */
    private fun mentions(text: String, name: String): Boolean {
        val n = norm(name)
        return n.length >= 2 && norm(text).contains(n)
    }

    /** "www.example.co.uk" -> "example" */
    private fun hostCore(host: String): String {
        val parts = host.removePrefix("www.").split('.').filter { it.isNotEmpty() }
        if (parts.size < 2) return host
        var p = parts.dropLast(1)                                   // drop the extension (.com, .uk ...)
        if (p.size > 1 && p.last().length <= 3) p = p.dropLast(1)   // and a second one (.co, .com ...)
        return p.last()
    }

    /**
     * "Full title - Channel - Site". The channel and the site are added only if the title doesn't
     * already say them, so nothing is repeated. The site always comes last, the title is trimmed first.
     */
    fun buildName(info: PageInfo): String {
        var title = info.title.trim()
        // Drop " - Site" / "| Site" at the end and "Site - " at the start that the page put in its own title.
        for (s in listOf(info.site, info.host).filter { it.isNotBlank() }) {
            val e = Regex.escape(s)
            title = title.replace(Regex("\\s*[-–—|·:]\\s*$e\\s*$", RegexOption.IGNORE_CASE), "")
            title = title.replace(Regex("^$e\\s*[-–—|·:]\\s*", RegexOption.IGNORE_CASE), "")
        }
        title = title.trim()

        val author = info.author.trim()
        val tail = mutableListOf<String>()
        if (author.isNotEmpty() && !mentions(title, author)) tail += author

        val site = info.site.trim().ifEmpty { info.host.trim() }
        val names = listOf(site, hostCore(info.host)).filter { norm(it).length >= 3 }
        val siteAlreadySaid = names.any { mentions(title, it) || mentions(author, it) }
        if (site.isNotEmpty() && !siteAlreadySaid) tail += site

        val suffix = tail.joinToString(" - ")
        val room = (MAX_NAME - suffix.length - 3).coerceAtLeast(20)
        title = title.take(room).trim()
        return (listOf(title) + tail).filter { it.isNotBlank() }.joinToString(" - ")
    }
}
