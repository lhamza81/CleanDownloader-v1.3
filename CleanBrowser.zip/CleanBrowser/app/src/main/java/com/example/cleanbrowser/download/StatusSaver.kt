package com.example.cleanbrowser.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class StatusFile(val uri: Uri, val name: String, val mime: String, val modified: Long) {
    val isVideo: Boolean get() = mime.startsWith("video/")
}

/**
 * Lists the statuses WhatsApp keeps on the phone and saves the ones you pick.
 * Android only lets an app read that folder after you pick it once, so it asks for access first.
 */
object StatusSaver {
    private const val PREFS = "prefs"
    private const val KEY = "status_tree"

    /** Where the folder picker should start. */
    fun pickerHint(): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
    )

    fun treeUri(ctx: Context): Uri? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)?.let { Uri.parse(it) }

    fun saveTree(ctx: Context, uri: Uri?) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (uri == null) e.remove(KEY) else e.putString(KEY, uri.toString())
        e.apply()
    }

    /** Throws if access to the folder was lost. */
    suspend fun list(ctx: Context, tree: Uri): List<StatusFile> = withContext(Dispatchers.IO) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val out = mutableListOf<StatusFile>()
        val cursor = ctx.contentResolver.query(children, cols, null, null, null)
            ?: throw IOException("Can't read the folder")
        cursor.use { c ->
            while (c.moveToNext()) {
                val mime = c.getString(2).orEmpty()
                if (mime.startsWith("video/") || mime.startsWith("image/")) {
                    out += StatusFile(
                        DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)),
                        c.getString(1).orEmpty(), mime, c.getLong(3),
                    )
                }
            }
        }
        out.sortedByDescending { it.modified }
    }

    /** Videos go to the download folder (and the Completed list), pictures to Pictures/CleanDownloader. */
    suspend fun save(ctx: Context, f: StatusFile): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
                .format(Date(f.modified.takeIf { it > 0 } ?: System.currentTimeMillis()))
            val resolver = ctx.contentResolver
            if (f.isVideo) {
                val base = "WhatsApp Status $stamp"
                val dest = Storage.create(ctx, "$base.mp4")
                resolver.openInputStream(f.uri)!!.use { i -> resolver.openOutputStream(dest, "wt")!!.use { o -> i.copyTo(o) } }
                Storage.finish(ctx, dest)
                val size = resolver.openAssetFileDescriptor(dest, "r")?.use { it.length } ?: 0L
                DownloadStore.add(
                    DownloadItem(
                        id = java.util.UUID.randomUUID().toString(), url = f.uri.toString(), pageUrl = "", userAgent = "",
                        name = base, state = DlState.COMPLETED, uri = dest.toString(), downloaded = size, total = size,
                        error = null, createdAt = System.currentTimeMillis(),
                    )
                )
            } else {
                val ext = when { f.mime.endsWith("png") -> "png"; f.mime.endsWith("webp") -> "webp"; else -> "jpg" }
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "WhatsApp Status $stamp.$ext")
                    put(MediaStore.Images.Media.MIME_TYPE, f.mime)
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CleanDownloader")
                }
                val dest = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("Couldn't create the picture")
                resolver.openInputStream(f.uri)!!.use { i -> resolver.openOutputStream(dest, "wt")!!.use { o -> i.copyTo(o) } }
            }
            true
        }.getOrDefault(false)
    }
}
