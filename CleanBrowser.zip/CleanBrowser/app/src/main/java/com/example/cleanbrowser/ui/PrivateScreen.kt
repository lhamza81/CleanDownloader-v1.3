package com.example.cleanbrowser.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.download.FileNames
import com.example.cleanbrowser.download.PrivateItem
import com.example.cleanbrowser.download.PrivateVault
import kotlinx.coroutines.launch
import java.io.File

/** Videos hidden from the gallery and other apps, opened with a PIN. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateScreen(onBack: () -> Unit, onPlay: (PlayRequest) -> Unit) {
    val ctx = LocalContext.current
    var hasPin by remember { mutableStateOf(PrivateVault.hasPin(ctx)) }
    var unlocked by remember { mutableStateOf(false) }
    var changePin by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Private folder") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (unlocked) {
                        var menu by remember { mutableStateOf(false) }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Change PIN") }, onClick = { menu = false; changePin = true })
                            DropdownMenuItem(text = { Text("Lock now") }, onClick = { menu = false; unlocked = false })
                        }
                    }
                },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                !hasPin -> PinForm(
                    title = "Create a PIN",
                    hint = "Choose 4 to 8 digits. You will need it every time you open this folder.",
                    confirm = true,
                ) { pin ->
                    PrivateVault.setPin(ctx, pin)
                    hasPin = true
                    unlocked = true
                    true
                }
                !unlocked -> PinForm(title = "Enter your PIN", hint = null, confirm = false) { pin ->
                    val ok = PrivateVault.checkPin(ctx, pin)
                    if (ok) unlocked = true
                    ok
                }
                else -> VaultList(onPlay)
            }
        }
    }
    if (changePin) ChangePinDialog { changePin = false }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(8)) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
    )
}

@Composable
private fun PinForm(title: String, hint: String?, confirm: Boolean, onSubmit: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Lock, null, Modifier.size(40.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (hint != null) {
            Text(hint, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        PinField("PIN", pin) { pin = it; error = null }
        if (confirm) PinField("Repeat PIN", again) { again = it; error = null }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        Button(onClick = {
            if (pin.length < 4) {
                error = "Use at least 4 digits"
            } else if (confirm && pin != again) {
                error = "The PINs don't match"
            } else if (!onSubmit(pin)) {
                error = "Wrong PIN"
                pin = ""
            }
        }) { Text(if (confirm) "Create" else "Unlock") }
    }
}

@Composable
private fun ChangePinDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var current by remember { mutableStateOf("") }
    var fresh by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PinField("Current PIN", current) { current = it; error = null }
                PinField("New PIN", fresh) { fresh = it; error = null }
                PinField("Repeat new PIN", again) { again = it; error = null }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = {
            TextButton(onClick = {
                if (!PrivateVault.checkPin(ctx, current)) {
                    error = "The current PIN is wrong"
                } else if (fresh.length < 4) {
                    error = "Use at least 4 digits"
                } else if (fresh != again) {
                    error = "The PINs don't match"
                } else {
                    PrivateVault.setPin(ctx, fresh)
                    Toast.makeText(ctx, "PIN changed", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            }) { Text("Change") }
        },
    )
}

@Composable
private fun VaultList(onPlay: (PlayRequest) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val items by PrivateVault.items.collectAsState()
    var deleting by remember { mutableStateOf<PrivateItem?>(null) }

    if (items.isEmpty()) {
        Text(
            "Nothing here yet. In Completed, press and hold a video, then tap the lock to move it here.",
            modifier = Modifier.padding(24.dp),
        )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(items, key = { it.id }) { p ->
            val uri = remember(p.file) { Uri.fromFile(File(p.file)) }
            val info by rememberMediaInfo(uri)
            val meta = listOfNotNull(
                Fmt.size(p.size),
                info?.durationSec?.let { Fmt.duration(it) },
                when (info?.hasAudio) { true -> "With audio"; false -> "No audio"; null -> null },
            ).joinToString(" · ")
            val frame = info?.frame

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerLow).padding(12.dp),
            ) {
                Row(Modifier.clickable { onPlay(PlayRequest(uri, FileNames.full(p.name))) }) {
                    Box(
                        Modifier.width(112.dp).height(72.dp).clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (frame != null) {
                            Image(frame.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        } else {
                            Icon(Icons.Filled.Movie, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(FileNames.full(p.name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = {
                        scope.launch {
                            val ok = PrivateVault.moveOut(ctx, p)
                            Toast.makeText(ctx, if (ok) "Moved back to your downloads" else "Couldn't move it", Toast.LENGTH_SHORT).show()
                        }
                    }) { Icon(Icons.Filled.LockOpen, "Move out of the private folder") }
                    IconButton(onClick = { deleting = p }) { Icon(Icons.Filled.Delete, "Delete") }
                }
            }
        }
    }

    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete this video?") },
            text = { Text(FileNames.full(p.name)) },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
            confirmButton = { TextButton(onClick = { PrivateVault.delete(p); deleting = null }) { Text("Delete") } },
        )
    }
}
