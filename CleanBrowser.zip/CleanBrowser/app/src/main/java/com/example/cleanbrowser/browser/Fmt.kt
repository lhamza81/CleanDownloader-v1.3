package com.example.cleanbrowser.browser

import kotlin.math.roundToLong

object Fmt {
    /** Always two decimals: 45.23 MB */
    fun size(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format("%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format("%.2f MB", bytes / (1L shl 20).toDouble())
        else -> String.format("%.2f KB", bytes / 1024.0)
    }

    /** 2.45 MB/s */
    fun rate(bytesPerSec: Long): String = size(bytesPerSec) + "/s"

    /** "1 h 05 min 12 sec", "12 min 34 sec", "34 sec" */
    fun duration(seconds: Double): String {
        val s = seconds.roundToLong()
        val h = s / 3600
        val m = (s % 3600) / 60
        val r = s % 60
        return when {
            h > 0 -> String.format("%d h %02d min %02d sec", h, m, r)
            m > 0 -> String.format("%d min %02d sec", m, r)
            else -> "$r sec"
        }
    }
}
