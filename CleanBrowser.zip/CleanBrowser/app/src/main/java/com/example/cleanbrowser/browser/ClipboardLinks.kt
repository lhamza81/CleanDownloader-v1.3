package com.example.cleanbrowser.browser

import android.content.ClipboardManager
import android.content.Context

/** Finds a web link the user just copied, once per link. */
object ClipboardLinks {
    private const val FILE = "prefs"
    private const val KEY = "last_clip"

    fun read(ctx: Context): String? {
        val clip = ctx.getSystemService(ClipboardManager::class.java).primaryClip ?: return null
        if (clip.itemCount == 0) return null
        val text = clip.getItemAt(0).text?.toString()?.trim() ?: return null
        val isLink = (text.startsWith("http://") || text.startsWith("https://")) &&
            !text.contains(' ') && !text.contains('\n')
        if (!isLink) return null
        val prefs = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        if (prefs.getString(KEY, null) == text) return null
        prefs.edit().putString(KEY, text).apply()
        return text
    }

    /** Called when the app copies a link itself, so it doesn't offer it back. */
    fun markHandled(ctx: Context, url: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, url).apply()
    }
}
