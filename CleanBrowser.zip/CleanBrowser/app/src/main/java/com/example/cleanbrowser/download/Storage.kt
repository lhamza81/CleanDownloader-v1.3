package com.example.cleanbrowser.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.IOException

/** Where finished videos live: the Downloads folder, or a folder the user picked in Settings. */
object Storage {
    private fun isMediaStore(uri: Uri) = uri.authority == MediaStore.AUTHORITY

    private fun customFolder(): Uri? = AppSettings.state.value.folderUri?.let { Uri.parse(it) }

    /** New empty video file. Falls back to Downloads if the picked folder can't be used any more. */
    fun create(ctx: Context, fileName: String): Uri {
        customFolder()?.let { tree ->
            val made = runCatching {
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                DocumentsContract.createDocument(ctx.contentResolver, parent, "video/mp4", fileName)
            }.getOrNull()
            if (made != null) return made
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)           // always ends with .mp4
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Couldn't create the file")
    }

    /** Makes a finished file visible to other apps (MediaStore files start hidden). */
    fun finish(ctx: Context, uri: Uri) {
        if (isMediaStore(uri)) {
            ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        }
    }

    fun delete(ctx: Context, uri: Uri) {
        runCatching {
            if (DocumentsContract.isDocumentUri(ctx, uri)) DocumentsContract.deleteDocument(ctx.contentResolver, uri)
            else ctx.contentResolver.delete(uri, null, null)
        }
    }

    /** @return the file's address after renaming (folder files can get a new one), or null if it failed. */
    fun rename(ctx: Context, uri: Uri, fileName: String): Uri? = runCatching {
        if (DocumentsContract.isDocumentUri(ctx, uri)) {
            DocumentsContract.renameDocument(ctx.contentResolver, uri, fileName)
        } else {
            val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, fileName) }
            if (ctx.contentResolver.update(uri, values, null, null) > 0) uri else null
        }
    }.getOrNull()

    /** Name of a picked folder, for the Settings screen. */
    fun folderName(ctx: Context, tree: Uri): String? = runCatching {
        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        ctx.contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
}
